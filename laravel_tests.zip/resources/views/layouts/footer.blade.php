<!-- Footer Start -->
<div id="footer">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <p>&copy; Copyright <a href="http://calmandcode.com">CalmAndCode</a>. All Rights Reserved</p>
            </div>
            <div class="col-md-6">
                <p>Template by <a href="">CalmAndCode</a></p>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->
