

<?php $__env->startSection('content'); ?>

    
        <?php $__currentLoopData = $product_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <!-- Products Start -->
        <div id="products">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="product-single">
                            <div class="product-img">
                                <img src="<?php echo e(asset('img/'.$product->image)); ?>" alt="Product Image">
                            </div>
                            <div class="product-content">
                                <h2><?php echo e($product->name); ?></h2>
                            

                            <?php if($product->sale_price != null): ?>
                        <h3>$<?php echo e($product->sale_price); ?></h3>
                        <h3 style="text-decoration: line-through;">
                            $<?php echo e($product->price); ?></h3>
                        <?php else: ?> 
                        <h3>$<?php echo e($product->price); ?></h3>

                        <?php endif; ?>

                        <p><?php echo e($product->description); ?></p>
                        <p><?php echo e($product->catogory); ?> - <?php echo e($product->type); ?></p>

                                <form method="POST" action="<?php echo e(route('add_to_cart')); ?>">
                                <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                    <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                    <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                    <input type="hidden" name="sale_price" value="<?php echo e($product->sale_price); ?>">
                                    <input type="hidden" name="quantity" value="1">
                                    <input type="hidden" name="image" value="<?php echo e($product->image); ?>">

                                    <input type="submit"  value="Add to Cart" class="btn" >

                                </form>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Products End -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_tests\resources\views/single_product.blade.php ENDPATH**/ ?>