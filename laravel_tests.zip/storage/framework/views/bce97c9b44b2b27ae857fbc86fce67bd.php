

<?php $__env->startSection('content'); ?>


<!-- Header Start-->
<div id="header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-7">
                <div class="header-content">
                    <h2><span>WATCH</span> is the best <span>Landing Page</span> to showcause your product</h2>
                    <ul class="fa-ul">
                        <li><span class="fa-li"><i class="far fa-arrow-alt-circle-right"></i></span>Android and iOS Support</li>
                        <li><span class="fa-li"><i class="far fa-arrow-alt-circle-right"></i></span>GPS & Health Tracker</li>
                        <li><span class="fa-li"><i class="far fa-arrow-alt-circle-right"></i></span>Read & reply to messages</li>
                        <li><span class="fa-li"><i class="far fa-arrow-alt-circle-right"></i></span>Compatible with all devices</li>
                    </ul>
                    <a class="btn" href="#">Buy Now</a>
                </div>
            </div>
            <div class="col-md-5">
                <div class="header-img">
                    <img src="<?php echo e(asset('img/watch-header.png')); ?>" alt="Product Image">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Header End-->



<!-- Process Start-->
<div id="process">
    <div class="container">
        <div class="section-header">
            <h2>How It Works</h2>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec viverra at massa sit amet ultricies
            </p>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="process-col">
                    <i class="fa fa-plug"></i>
                    <h2>Connect Device</h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipiscing elit. In sed lorem efficitur vestibulum erat finibus
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="process-col">
                    <i class="fa fa-sliders-h"></i>
                    <h2>Configure it</h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipiscing elit. In sed lorem efficitur vestibulum erat finibus
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="process-col">
                    <i class="fa fa-check"></i>
                    <h2>Done. Enjoy!!!</h2>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipiscing elit. In sed lorem efficitur vestibulum erat finibus
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Process End-->


<!-- Products Start -->
<div id="products">
    <div class="container">
        <div class="section-header">
            <h2>Get Your Products</h2>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec viverra at massa sit amet ultricies
            </p>
        </div>
        <div class="row align-items-center">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-3">
                <div class="product-single">
                    <div class="product-img">
                        <img src="<?php echo e(asset('img/'.$product->image)); ?>" alt="Product Image">
                    </div>
                    <div class="product-content">
                        <h2>
                            <a href="<?php echo e(route('single_product', ['id'=> $product->id])); ?>">
                                <?php echo e($product->name); ?>

                            </a>
                        </h2>

                        <?php if($product->sale_price != null): ?>
                        <h3>$<?php echo e($product->sale_price); ?></h3>
                        <h3 style="text-decoration: line-through;">
                            $<?php echo e($product->price); ?></h3>
                        <?php else: ?> 
                        <h3>$<?php echo e($product->price); ?></h3>

                        <?php endif; ?>
                        

                        <form method="POST" action="<?php echo e(route('add_to_cart')); ?>">
                            <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
                                <input type="hidden" name="sale_price" value="<?php echo e($product->sale_price); ?>">
                                <input type="hidden" name="quantity" value="1">
                                <input type="hidden" name="image" value="<?php echo e($product->image); ?>">

                                <input type="submit"  value="Add to Cart" class="btn" >

                            </form>



                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

        <!--<div class="mt-5 text-center"><a href="" class="btn btn-primary">Buy Now</a></div>  -->

    </div>
</div>
<!-- Products End -->











    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_tests\resources\views/index.blade.php ENDPATH**/ ?>