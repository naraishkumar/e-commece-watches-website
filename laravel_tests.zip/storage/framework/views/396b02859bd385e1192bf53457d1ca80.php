

<?php $__env->startSection('content'); ?>

 <!-- Cart Start -->
 <div class="container-fluid pt-5">
    <div class="container">
    
<section class="cart container mt-2 my-3 py-5">
    <div class="container mt-2">
        <h4>Your Cart</h4>
    </div>

    <table class="pt-5">
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Subtotal</th>
        </tr>

        <?php if(Session::has('cart')): ?>
            <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="product-info">
                            <img style="width: 75px; height: 75px" src="<?php echo e(asset('img/'.$product['image'])); ?>">
                            <div>
                                <p><?php echo e($product['name']); ?></p>
                                <small><span>$</span><?php echo e($product['price']); ?></small>
                                <br>
                                <form method="POST" action="<?php echo e(route('remove_from_cart')); ?>"> 
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($product['id']); ?>">
                                    <input type="submit" name="remove_btn" class="remove-btn" value="remove">
                                </form>
                            </div>
                        </div>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('edit_product_quantity')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="-" class="edit-btn" name="decrease_product_quantity_btn">

                            <input type="hidden" name="id" value="<?php echo e($product['id']); ?>">

                            <input type="text" name="quantity" value="<?php echo e($product['quantity'] ?? 1); ?>" readonly>

                            <input type="submit" value="+" class="edit-btn" name="increase_product_quantity_btn">
                        </form>
                    </td>
                    <td>
                        <span class="product-price">$<?php echo e($product['price'] * ($product['quantity'] ?? 1)); ?></span>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </table>

    <div class="cart-total">
        <table>
            <?php if(Session::has('cart')): ?>
                <tr>
                    <td>Total</td>
                    <?php if(Session::has('total')): ?>
                        <td>$<?php echo e(Session::get('total')); ?></td>
                    <?php endif; ?>
                </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="checkout-container">
        <form method="POST" action="<?php echo e(route('checkout')); ?>">
            <?php echo csrf_field(); ?>
            <input type="submit" class="btn checkout-btn" value="Checkout" name="">
        </form>
    </div>
</section>
    
    </div>
</div>
<!-- Cart End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_tests\resources\views/cart.blade.php ENDPATH**/ ?>